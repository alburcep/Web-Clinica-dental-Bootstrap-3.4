window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 40 || document.documentElement.scrollTop > 40) {
    document.getElementById("navOcultar").style.display = "block";
  } else {
    document.getElementById("navOcultar").style.display = "none";
  }
}