
Titular no centrado en Equipo - Ok

carillas eliminar - Ok

5º en 1r lugar y mejrar calidad - Ok

Flechas. Para manejar el slider - Ok

quitar color a las control circles. Cŕiculo blanco y luego círculo verde - Ok

https://clinicaprimitivoroig.com/

NS CLINICA DENTAL desde 1979 -> Rectángulo. Botón -> Pide tu primera visita sin coste -> Nos lleva al apartado Pide tu Cita (Contacto) - Ok

Intentamos el menú encima de las fotos.
https://clinicaprimitivoroig.com/#cita-previa - No resulta

